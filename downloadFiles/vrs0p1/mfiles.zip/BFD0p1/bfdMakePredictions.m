function [predY, probY] = bfdMakePredictions(model, trainF, ...
                                             trainY, testF)

% BFDMAKEPREDICTIONS Assigns labels to test data 
%
% [predY, probY] = bfdMakePredictions(model, trainF, ...
%                                              trainY, testF)

% Copyright (c) 2004 Tonatiuh Pena Centeno
% File version 1.2, Wed Dec  1 12:34:40 2004
% BFD toolbox version 0.1



% Computing Class conditional probs
[p1, p0] = bfdComputeCCProbs(model, trainF, trainY, testF);

% Assigning predicted labels according to class cond. probs
predY = p1 >= p0;
probY = [p1, p0];

