function Ltheta = bfdBound(model)

% BFDBOUND Computes bound on marginal log-likelihood
%
% Ltheta = bfdBound(model)

% Copyright (c) 2004 Tonatiuh Pena Centeno
% File version 1.3, Wed Dec  1 12:34:40 2004
% BFD toolbox version 0.11



% Computes the bound of the logmarginal likelihood
% Prior over Beta is included
[invSigma,UC] = pdinv(model.Sigma);
K = model.kern.Kstore;
N = size(model.y, 1);
Ltheta = - 0.5*( N*log(2*pi) - N*log(model.beta) ...
                + logdet(K) + logdet(invSigma, UC) )...
         + gammaPriorLogProb(model.gamma, model.beta);