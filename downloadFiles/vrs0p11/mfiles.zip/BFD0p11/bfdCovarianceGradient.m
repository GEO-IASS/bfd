function g = bfdCovarianceGradient(invK, postK)

% BFDCOVARINCEGRADIENT Gradient of marginal log-likelihood wrt K
%
% g = bfdCovarianceGradient(invK, postK)

% Copyright (c) 2004 Tonatiuh Pena Centeno
% File version 1.3, Wed Dec  1 12:34:40 2004
% BFD toolbox version 0.11



% invK is the inverted Kernel
g = -invK + invK*(postK)*invK;
g = g*.5;
