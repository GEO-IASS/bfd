function model = bfdUpdateSigma(model)

% BFDUPDATESIGMA Update the posterior for BFD
%
% model = bfdUpdateSigma(model)

% Copyright (c) 2004 Tonatiuh Pena Centeno
% File version 1.2, Tue Nov 23 16:52:26 2004
% BFD toolbox version 0.11



model.Sigma = pdinv(pdinv(model.kern.Kstore) ...
                   + model.beta*model.L);