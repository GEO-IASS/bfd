% BFD toolbox
% Version 0.11 Monday, December 6, 2004 at 19:15:29
% Copyright (c) 2004 Tonatiuh Pena Centeno
% 
% BFD Creates a model with parameters and required specifications
% BFDBOUND Computes bound on marginal log-likelihood
% BFDCOMPUTEALPHA Computes the 'eigenvectors' of the model
% BFDCOMPUTECCPROBS Computes Class Conditional Probs for BFD
% BFDCOMPUTEERROR Computes prediction error on test data
% BFDCOMPUTEL Computes matrix that clusters targets
% BFDCOVARINCEGRADIENT Gradient of marginal log-likelihood wrt K
% BFDKERNELGRADIENT Gradient of KL divergence wrt kernel parameters.
% BFDKERNELOBJECTIVE KL divergence between prior and posterior kernels 
% BFDLOADDATA Loads NINST files belonging to data set NAME
% BFDMAKEPREDICTIONS Assigns labels to test data 
% BFDMIDPRODUCT Auxiliary function to compute variance of a test point
% BFDOPTIMISEBFD Optimises a BFD model
% BFDOPTIMISEKERNEL Applies OPTIMETHOD to optimise parameters of a MODEL
% BFDPARAMINIT Initialises kernel parameters
% BFDPLOT Plot the discriminant defined by the MODEL
% BFDPROJECTDATA Projects training and test data over discriminant
% BFDSAVEDATA Saves results of (training a/classifying with a) BFD model
% BFDSELECTWIDTH Selects arameters in terms of the marginal like
% TESTTOYPARAMS Plots 
% BFDTRAINMODEL Trains several BFD models according to partitions/trialWidths  
% BFDUPDATEBETA Update precision beta
% BFDUPDATESIGMA Update the posterior for BFD
% CLASSDEMO Script to classify a given data set (e.g. from UCI)
% DEMOBFD Demo for classifying a given Toy data set
% SETOPTIONS Converts an optimset structure to a vector foptions
% TOYDEMO Script to classify Toy data and to plot the results
