function model = bfdComputeAlpha(model)

% BFDCOMPUTEALPHA Computes the 'eigenvectors' of the model
%
% model = bfdComputeAlpha(model)

% Copyright (c) 2004 Tonatiuh Pena Centeno
% File version 1.2, Tue Nov 23 16:52:25 2004
% BFD toolbox version 0.11



% Computing projected means and alpha coeffs.
m1 = model.kern.Kstore*model.y/sum(model.y);
m0 = model.kern.Kstore*(1-model.y)/sum(1-model.y);
alpha = pdinv(model.kern.Kstore*1/model.beta ...
              + model.kern.Kstore*model.L*model.kern.Kstore)*(m0-m1);
model.alpha = model.d*alpha/(alpha'*(m0-m1));