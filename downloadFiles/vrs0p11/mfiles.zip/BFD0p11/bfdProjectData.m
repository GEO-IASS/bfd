function [trainF, testF, model] = bfdProjectData(trainX, trainY, testX, ...
                                              testY, modSpecs, params)

% BFDPROJECTDATA Projects training and test data over discriminant
%
% [trainF, testF, model] = bfdProjectData(trainX, trainY, testX, ...
%                                               testY, modSpecs, params)

% Copyright (c) 2004 Tonatiuh Pena Centeno
% File version 1.2, Wed Dec  1 12:34:40 2004
% BFD toolbox version 0.11



%Creating a model with training data 
[model, K] = bfd(trainX, trainY, modSpecs, ...
                           params(1:end-1), params(end));
  
% Projecting the data on the line of discrimination
trainF = K*model.alpha;
  
% Obtaining projections of new test points
testF  = kernCompute(model.kern, testX, model.X)*model.alpha;