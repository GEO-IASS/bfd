function g = bfdKernelGradient(params, model)

% BFDKERNELGRADIENT Gradient of KL divergence wrt kernel parameters.
%
% g = bfdKernelGradient(params, model)

% Copyright (c) 2004 Tonatiuh Pena Centeno
% File version 1.2, Tue Nov 23 16:52:25 2004
% BFD toolbox version 0.11




% Verifying parameters are fine
if any(isnan(params))
  warning('Parameter is NaN')
end

% Computing the gradient
x = model.X(model.I, :);
model.kern = kernExpandParam(model.kern, params);
K = kernCompute(model.kern, x);
g = zeros(size(params));

invK = pdinv(K);
covGrad = bfdCovarianceGradient(invK, model.Sigma);

g = kernGradient(model.kern, x, covGrad);
g = -g;