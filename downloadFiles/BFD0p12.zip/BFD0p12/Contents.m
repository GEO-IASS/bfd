% BFD toolbox
% Version 0.12		Friday 17 Feb 2006 at 10:02
% Copyright (c) 2006 Tonatiuh Pena Centeno

% 
% BFDCOMPUTEBOUND Computes bound of marginal log-likelihood
% BFDCREATEMODEL Creates a model with specified parameters
% DEMTOY Function to classify TOY data sets
% BFDCLASSIFYDATA Function used to classify a given dataset 
% BFDCOVARIANCEGRADIENT Gradient of L(\Theta) wrt Kernel matrix
% BFDCOMPUTEALPHA Computes coefficients alpha
% BFDCOMPUTEL Computes matrix L
% BFDMATVAR Computes matrix associated to likelihood variance
% BFDHIST Generates plot with histograms of projected data
% BFDKERNELGRADIENT Gradient of likelihood wrt kernel parameters.
% BFDKERNELOBJECTIVE Likelihood 
% BFDOPTIMISEBFD Adapts kernel parameters by EM algorithm
% BFDPLOT Plots the discriminant function
% BFDSAVEDATA Saves into a file the results of training a BFD model
% BFDUPDATEBETA Update the value for beta.
% BFDUPDATESIGMA Update the posterior for Fisher's discriminant.
% CLASSSPECSRBFBIASWHITE Script that generates vector of OPTIONS
% CLASSSPECSRBFARDLINARDBIASWHITE Script that generates vector of OPTIONS 
% COMPUTEKERNEL Compute kernel given parameters LNTHETA and data X  
% DELELEMENTS deletes columns or rows of a given matrix
% DEMAUCBANANA Demo to obtain AUC statistics for banana dataset
% DEMAUCBREASTCANCER Demo to obtain AUC statistics for breast-cancer dataset
% DEMAUCHEART Demo to obtain AUC statistics for heart dataset
% DEMHISTTWONORM Demo for histograms of projections of Twonorm data  
% DEMHISTWAVEFORM Demo for histograms of projections of Waveform 
% GENERATEHIST Creates histogram of the output distribution
% GENERATEROC Creates ROC curves for a given dataset
% INITTHETA Initialise the kernel parameters.
% LOADDATA Loads data and labels for a given partition of a dataset
% PROCESSROCDATA Computes mean and std from the ROC-generated data 
% PROJECTDATA Projects training and test data over discriminant
% SELECTPARAMSANDPROJECT projects data with selected model params 
% SELECTPARAMSFROMARRAY selects median parameters 
% SETOPTIONS Converts an OPTSET structure into a vector of OPTIONS
% THETACONSTRAIN Prevents kernel parameters from getting too big or small.
