
% DEMAUCBREASTCANCER Demo to obtain AUC statistics for breast-cancer dataset
%
% 

% Copyright (c) 2006 Tonatiuh Pena Centeno

% demAUCbreastCancer.m version 1.17



% 
% Syntax:
% demAUCbreastCancer
%
% Description:
% This script can be run to recreate the results of the BFD paper,
% see [1] in README file.
%

% Defining parameters
dataset = 'breast-cancer';
kernelType = {'rbf', 'bias', 'white'};
dataType = 'test';
% Selecting parameters from stored results
selectParamsAndProject(dataset, kernelType, dataType, [10, 100], []);
% Generating ROC curves. Stored plot in a directory
generateROC(dataset, dataType, kernelType);
% Processing ROC data. Writes results into a file
processROCdata(dataset, dataType, kernelType); 